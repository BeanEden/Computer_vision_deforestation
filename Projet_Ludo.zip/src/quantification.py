import numpy as np

def calculate_surface(mask):
    """Calculates the number of vegetation pixels (proxy for surface)."""
    return np.sum(mask > 0)

def compute_deforestation_stats(mask_t0, mask_t1):
    """
    Computes surface areas and loss percentage.
    """
    surf_t0 = calculate_surface(mask_t0)
    surf_t1 = calculate_surface(mask_t1)
    
    # Loss = (surf_t0 - surf_t1) / surf_t0
    if surf_t0 > 0:
        loss = (float(surf_t0) - float(surf_t1)) / float(surf_t0)
    else:
        loss = 0.0
        
    return {
        'surface_t0': surf_t0,
        'surface_t1': surf_t1,
        'loss_ratio': loss,
        'loss_percentage': loss * 100
    }

def get_change_map(mask_t0, mask_t1):
    """
    Creates a map where:
    - 0: No vegetation at both times
    - 1: Consistent vegetation
    - 2: Deforestation (Veg at t0, not at t1)
    - 3: Reforestation (Not at t0, Veg at t1)
    """
    change_map = np.zeros_like(mask_t0)
    
    # Consistent
    change_map[(mask_t0 > 0) & (mask_t1 > 0)] = 1
    
    # Deforestation
    change_map[(mask_t0 > 0) & (mask_t1 == 0)] = 2
    
    # Reforestation
    change_map[(mask_t0 == 0) & (mask_t1 > 0)] = 3
    
    return change_map
