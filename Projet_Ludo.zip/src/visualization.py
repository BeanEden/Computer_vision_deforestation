import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

def plot_side_by_side(img_a, img_b, title_a="Avant (t0)", title_b="Après (t1)", main_title="Comparaison"):
    """Displays two images side by side."""
    plt.figure(figsize=(15, 7))
    
    plt.subplot(1, 2, 1)
    plt.imshow(img_a)
    plt.title(title_a)
    plt.axis('off')
    
    plt.subplot(1, 2, 2)
    plt.imshow(img_b)
    plt.title(title_b)
    plt.axis('off')
    
    plt.suptitle(main_title, fontsize=16)
    plt.tight_layout()
    plt.show()

def plot_histograms(img_a, img_b, title="Analyse des Histogrammes"):
    """Plots RGB histograms for both images."""
    colors = ('r', 'g', 'b')
    plt.figure(figsize=(15, 5))
    
    plt.subplot(1, 2, 1)
    for i, col in enumerate(colors):
        hist = np.histogram(img_a[:,:,i], bins=256, range=(0, 256))[0]
        plt.plot(hist, color=col)
    plt.title("Histogramme t0")
    
    plt.subplot(1, 2, 2)
    for i, col in enumerate(colors):
        hist = np.histogram(img_b[:,:,i], bins=256, range=(0, 256))[0]
        plt.plot(hist, color=col)
    plt.title("Histogramme t1")
    
    plt.suptitle(title)
    plt.show()

def plot_change_map(change_map):
    """
    Plots the change map with custom labels.
    - 0: Background
    - 1: Consistent Vegetation (Green)
    - 2: Deforestation (Red)
    - 3: Reforestation (Blue)
    """
    from matplotlib.colors import ListedColormap
    
    cmap = ListedColormap(['black', 'green', 'red', 'blue'])
    plt.figure(figsize=(10, 10))
    plt.imshow(change_map, cmap=cmap)
    cbar = plt.colorbar(ticks=[0, 1, 2, 3])
    cbar.ax.set_yticklabels(['Autre', 'Forêt Stable', 'Déforestation', 'Reboisement'])
    plt.title("Carte de l'évolution de la couverture forestière")
    plt.axis('off')
    plt.show()
