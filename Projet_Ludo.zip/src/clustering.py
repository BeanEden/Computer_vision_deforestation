import numpy as np
from sklearn.cluster import KMeans, AgglomerativeClustering
from scipy.cluster.hierarchy import dendrogram, linkage
import matplotlib.pyplot as plt

def sample_pixels(features, n_samples=1000):
    """Samples a subset of pixels for CAH."""
    indices = np.random.choice(features.shape[0], size=min(n_samples, features.shape[0]), replace=False)
    return features[indices]

def run_cah(sampled_features, n_clusters=3):
    """
    Performs Hierarchical Clustering on a sample.
    Returns the linkage matrix for dendrogram visualization.
    """
    Z = linkage(sampled_features, method='ward')
    return Z

def run_kmeans(features, n_clusters=3):
    """
    Performs K-means on the full feature set.
    """
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init='auto')
    labels = kmeans.fit_predict(features)
    return labels, kmeans.cluster_centers_

def identify_vegetation_cluster(features, labels, cluster_centers, green_ratio_idx=6):
    """
    Automatically identifies the vegetation cluster based on the highest Green Ratio.
    Typically, green_ratio is at index 6 (after 3 RGB and 3 HSV channels).
    """
    n_clusters = len(np.unique(labels))
    ratios = []
    
    for i in range(n_clusters):
        # We can use cluster centers directly if they are representative
        ratio_val = cluster_centers[i, green_ratio_idx]
        ratios.append(ratio_val)
        
    veg_cluster = np.argmax(ratios)
    return veg_cluster

def get_vegetation_mask(labels, veg_cluster, shape):
    """Converts labels to a binary mask for vegetation."""
    mask = (labels == veg_cluster).astype(np.uint8)
    return mask.reshape(shape)
