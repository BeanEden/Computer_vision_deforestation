import cv2

def apply_morphology(mask, kernel_size=5, iterations=1):
    """
    Cleans the mask using morphological opening and closing.
    - Opening: remove small dots (noise).
    - Closing: fill small holes.
    """
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
    
    # Opening
    cleaned = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=iterations)
    
    # Closing
    cleaned = cv2.morphologyEx(cleaned, cv2.MORPH_CLOSE, kernel, iterations=iterations)
    
    return cleaned
