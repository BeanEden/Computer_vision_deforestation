import os
import cv2
import glob

def get_image_pairs(data_dir):
    """
    Identifies common image pairs between Lo1_A and Lot1_B.
    Returns a list of tuples (path_a, path_b) for matching filenames.
    """
    path_a = os.path.join(data_dir, 'Lo1_A')
    path_b = os.path.join(data_dir, 'Lot1_B')
    
    files_a = glob.glob(os.path.join(path_a, '*.png'))
    files_b = glob.glob(os.path.join(path_b, '*.png'))
    
    names_a = {os.path.basename(f): f for f in files_a}
    names_b = {os.path.basename(f): f for f in files_b}
    
    common_names = sorted(set(names_a.keys()) & set(names_b.keys()))
    
    pairs = [(names_a[name], names_b[name]) for name in common_names]
    
    missing_b = set(names_a.keys()) - set(names_b.keys())
    if missing_b:
        print(f"Warning: {len(missing_b)} images in A have no match in B: {missing_b}")
        
    return pairs

def load_pair(pair):
    """Loads a pair of images from paths."""
    img_a = cv2.imread(pair[0])
    img_b = cv2.imread(pair[1])
    
    # Convert BGR (OpenCV default) to RGB
    img_a = cv2.cvtColor(img_a, cv2.COLOR_BGR2RGB)
    img_b = cv2.cvtColor(img_b, cv2.COLOR_BGR2RGB)
    
    return img_a, img_b
