import cv2
import numpy as np

def compute_green_ratio(img_rgb):
    """
    Computes the Green Ratio: G / (R + G + B).
    Handles division by zero.
    """
    R = img_rgb[:,:,0].astype(float)
    G = img_rgb[:,:,1].astype(float)
    B = img_rgb[:,:,2].astype(float)
    
    total = R + G + B
    # Avoid div by zero
    ratio = np.divide(G, total, out=np.zeros_like(G), where=total!=0)
    return ratio

def compute_local_features(img_gray, window_size=5):
    """
    Computes local mean and variance.
    """
    # Mean
    mean = cv2.blur(img_gray.astype(float), (window_size, window_size))
    
    # Square of Mean
    mean_sq = mean ** 2
    
    # Mean of Squares
    sq_img = img_gray.astype(float) ** 2
    mean_sq_img = cv2.blur(sq_img, (window_size, window_size))
    
    # Variance = E(X^2) - [E(X)]^2
    variance = mean_sq_img - mean_sq
    variance = np.maximum(variance, 0) # Ensure no numerical errors < 0
    
    return mean, variance

def get_feature_vector(img_rgb):
    """
    Constructs the feature vector for clustering.
    - RGB channels
    - HSV Channels (H, S) - V might be redundant with RGB intensity
    - Green Ratio
    - Local Mean (of Grayscale)
    - Local Variance (of Grayscale)
    """
    # RGB
    h, w, _ = img_rgb.shape
    rgb_feat = img_rgb.reshape(-1, 3) / 255.0
    
    # HSV
    img_hsv = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2HSV)
    hsv_feat = img_hsv.reshape(-1, 3).astype(float)
    hsv_feat[:, 0] /= 180.0 # H
    hsv_feat[:, 1] /= 255.0 # S
    hsv_feat[:, 2] /= 255.0 # V
    
    # Green Ratio
    ratio = compute_green_ratio(img_rgb)
    ratio_feat = ratio.reshape(-1, 1)
    
    # Local Stats (on Grayscale)
    img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2GRAY)
    l_mean, l_var = compute_local_features(img_gray)
    
    l_mean_feat = (l_mean.reshape(-1, 1) / 255.0)
    l_var_feat = (l_var.reshape(-1, 1) / (255.0**2))
    
    # Stack all features
    # Based on prompt: RGB, HSV, Ratio G, Local Mean, Local Var
    features = np.hstack([rgb_feat, hsv_feat, ratio_feat, l_mean_feat, l_var_feat])
    
    return features
