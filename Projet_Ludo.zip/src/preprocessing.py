import cv2

def denoise_image(img_rgb, method='gaussian', kernel_size=3):
    """
    Applies denoising.
    Methods: 'gaussian', 'median', 'bilateral'
    """
    if method == 'gaussian':
        return cv2.GaussianBlur(img_rgb, (kernel_size, kernel_size), 0)
    elif method == 'median':
        return cv2.medianBlur(img_rgb, kernel_size)
    elif method == 'bilateral':
        return cv2.bilateralFilter(img_rgb, kernel_size, 75, 75)
    return img_rgb

def improve_contrast(img_rgb):
    """
    Applies CLAHE on the L channel of Lab space to improve contrast.
    """
    lab = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    cl = clahe.apply(l)
    limg = cv2.merge((cl,a,b))
    return cv2.cvtColor(limg, cv2.COLOR_LAB2RGB)

def preprocess(img_rgb, denoise_method='gaussian', k_size=3, contrast=True):
    """Pipeline of preprocessing."""
    img = img_rgb.copy()
    if denoise_method:
        img = denoise_image(img, method=denoise_method, kernel_size=k_size)
    if contrast:
        img = improve_contrast(img)
    return img
